/** @format */
// eslint-disable-next-line no-unused-vars
const ServerGlobalConstant = {
    ctx: '/suichang',
    routerMode: 'hash'
};

ServerGlobalConstant.BASE_URL = '';
//'http://183.131.138.90:8384/suichang';
// 'http://localhost:9099/suichang';
